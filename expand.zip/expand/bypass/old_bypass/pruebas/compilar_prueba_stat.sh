#!/bin/bash
make clean_prueba_stat && make prueba_stat && ./prueba_stat $1

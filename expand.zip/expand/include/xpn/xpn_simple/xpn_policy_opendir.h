#ifndef _XPN_POLICY_DIR_H
#define _XPN_POLICY_DIR_H

#include "xpn_file.h"
#include "xpn.h"


 #ifdef  __cplusplus
    extern "C" {
 #endif

int XpnGetEntry(int fd , char *entry, unsigned char *type);


 #ifdef  __cplusplus
     }
 #endif

#endif

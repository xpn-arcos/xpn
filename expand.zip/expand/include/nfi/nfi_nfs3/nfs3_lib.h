#ifndef _NFS3_LIB_H_
#define _NFS3_LIB_H_

#include "nfi_nfs3.h"

#endif

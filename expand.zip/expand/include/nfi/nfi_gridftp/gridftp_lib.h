#ifndef _GRIDFTP_LIB_H_
#define _GRIDFTP_LIB_H_

#include "nfi_gridftp.h"

#endif

#!/bin/sh
set -x
/export/home/pato11-1/proyectos/xpn/expand-2.0/test/pruebas/run1.sh
/export/home/pato11-1/proyectos/xpn/expand-2.0/test/pruebas/run2.sh
/export/home/pato11-1/proyectos/xpn/expand-2.0/test/pruebas/runp.sh

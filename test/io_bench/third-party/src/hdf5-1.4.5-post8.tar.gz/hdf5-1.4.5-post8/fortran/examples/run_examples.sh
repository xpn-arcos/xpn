#! /bin/sh

./dsetexample
./fileexample
./rwdsetexample
./attrexample
./groupexample
./grpsexample
./grpdsetexample
./hyperslab
./selectele
./grpit
./refobjexample
./refregexample
